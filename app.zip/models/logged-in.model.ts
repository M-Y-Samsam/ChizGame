export interface LoggedIn{
    name:string;
    email:string;
    age:number;
    token: string;
    profilePhotoUrl: string | undefined;
}