namespace api.Interfaces;

public interface IGameRepository
{
    public Task<Games?> AddGameAsync(Games input, CancellationToken cancellationToken);
}