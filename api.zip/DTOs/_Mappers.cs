namespace api.DTOs;

public static class Mappers
{
    public static Gamer ConvertRegisterDtoToGamer(RegisterDto registerDto)
    {
        Gamer gamer = new Gamer()
        {
            UserName = registerDto.Name.Trim().ToLower(),
            Email = registerDto.Email.Trim().ToLower(),
            DateOfBirth = registerDto.DateOfBirth,
            Gender = registerDto.Gender,
        };

        return gamer;
    }

    public static LoggedInDto ConvertGamerToLoggedInDto(Gamer gamer, string tokenValue)
    {
        return new LoggedInDto
        {
            Email = gamer.Email,
            UserName = gamer.UserName,
            Age = DateTimeExtension.CalculateAge(gamer.DateOfBirth),
            Token = tokenValue,
            ProfilePhotoUrl = gamer.Photo?.Url_165
        };
    }

    public static MemberDto ConvertGamerToMemberDto(Gamer gamer)
    {
        return new(
            Name: gamer.UserName!,
            Age: DateTimeExtension.CalculateAge(gamer.DateOfBirth),
            Gender: gamer.Gender,
            City: gamer.City,
            Country: gamer.Country,
            Photo: gamer.Photo,
            FavoriteGames: gamer.FavoriteGames,
            LastActive: gamer.LastActive
        );
    }

    public static Photo ConvertPhotoUrlsToPhoto(string[] photoUrls, bool isMain)
    {
        return new Photo(
            Url_165: photoUrls[0],
            Url_256: photoUrls[1],
            Url_enlarged: photoUrls[2],
            IsMain: isMain
        );
    }
}