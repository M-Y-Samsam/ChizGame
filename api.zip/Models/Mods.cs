namespace api.Models;

public class Mods
{
    [property: BsonId, BsonRepresentation(BsonType.ObjectId)]
    public string? Id {get; init;}
    public string ModName {get ; init;}
    public string GameName {get; init;}
    public string Creator {get; init;}
}