using api.Enums;
using api.Models;
using api.Models.Helpers;
namespace api.Models;

public class Games
{

    [property: BsonId, BsonRepresentation(BsonType.ObjectId)]
    public string? Id { get; init; } // Game Id in Database
    public string Title { get; init; } = string.Empty; // Game Name
    public string Slug { get; init; } = string.Empty; // Clean Name For Url

    public GameDescreption GameDescreption { get; init; } = default!;

    public Photo CoverImage { get; init; } = default!; // the image that is in get all games page
    public Photo BannerImage { get; init; } = default!; // main image in game page
    public List<Photo> Screenshots { get; init; } = []; // Gameplay images

    public string TrailerUrl { get; init; } = string.Empty; // Game Trailer Url

    public List<GameTags> GameTags { get; init; } = []; // Game Tags And Categorys

    public string Developer { get; init; } = string.Empty; // Game Compony
    public string Publisher { get; init; } = string.Empty; // Game Publisher
    public DateOnly ReleaseDate { get; init; } // Date of Releasing Game

    public List<Platforms> Platforms { get; init; } = []; //Platforms supported by this game

    public GameRequirement MinimumRequirements { get; init; } = default!; // Minimum system requirements for this game
    public GameRequirement MaximumRequirements { get; init; } = default!; // Maximum system requirements for this game

    public List<GameDownloadLink> DownloadLinks { get; init; } = [];
}
