namespace api.Models.Helpers;

public record GameRequirement
(
    
);