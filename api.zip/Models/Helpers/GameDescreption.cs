namespace api.Models.Helpers;

public record GameDescreption(
    string ShortDescription, // for Cover before opening game page
    string FullDescription  // in Game page
);