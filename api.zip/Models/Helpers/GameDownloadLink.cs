using api.Enums;

namespace api.Models.Helpers;

public record GameDownloadLink(
    Platforms Platform,
    string DownloadLink,
    double GameSize
);