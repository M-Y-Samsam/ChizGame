using api.Models.Helpers;

namespace api.Repositories;

public class GameRepository : IGameRepository
{
    #region Mongodb
    private readonly IMongoCollection<Games> _collection;
    private readonly ITokenService _tokenService;

    // Dependency Injection
    public GameRepository(IMongoClient client, IMyMongoDbSettings dbSettings, ITokenService tokenService)
    {
        var dbName = client.GetDatabase(dbSettings.DatabaseName);
        _collection = dbName.GetCollection<Games>("games");

        _tokenService = tokenService;
    }
    #endregion
    public async Task<Games?> AddGameAsync(Games input, CancellationToken cancellationToken)
    {
        Games? game1 = await _collection.Find<Games>(doc => doc.Slug == input.Slug).FirstOrDefaultAsync(cancellationToken);
        Games? game2 = await _collection.Find<Games>(doc => doc.Title == input.Title).FirstOrDefaultAsync(cancellationToken);

        if (game1 is not null && game2 is not null) return null;

        string shortDes = input.GameDescreption.ShortDescription;
        string fullDes = input.GameDescreption.FullDescription;

        Games games = new Games()
        {
            Title = input.Title,
            Slug = input.Title,

            GameDescreption = new GameDescreption(shortDes, fullDes),
            
            CoverImage = input.CoverImage,
            BannerImage = input.BannerImage,
            Screenshots = input.Screenshots,

            TrailerUrl = input.TrailerUrl,

            GameTags = input.GameTags,

            Developer = input.Developer,
            Publisher = input.Publisher,
            ReleaseDate = input.ReleaseDate,

            Platforms = input.Platforms,

        };

        await _collection.InsertOneAsync(games, null, cancellationToken);

        return games;
    }
}